function setup() {
  createCanvas(400, 400);
  var x = 5;
  var y = 10;
  var sum = x + y;
}

function draw() {
  background(220);
  
  console.log(sum);
}